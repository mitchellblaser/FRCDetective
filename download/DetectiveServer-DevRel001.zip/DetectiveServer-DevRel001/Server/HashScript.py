# FRC Detective
# HashScript.py
# Created 4-2-21

def process(data):
	print("Hash")