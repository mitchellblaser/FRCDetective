# FRC Detective
# GFXLowLevel.py
# Created 4-2-21

def initGraphics():
	print("Low Level Graphics Initialised.")

def updateGraphics():
	print("u")

def setStatus(_status):
	print("s")